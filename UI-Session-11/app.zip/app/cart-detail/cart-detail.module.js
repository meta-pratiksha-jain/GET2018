angular.module('cartDetail',[
    'ngRoute'
]);