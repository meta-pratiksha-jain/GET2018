angular.module('shippingDetail',[
    'ngRoute'
]);