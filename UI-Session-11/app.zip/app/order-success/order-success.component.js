angular.module('orderSuccess').
    component('orderSuccess',{
        templateUrl:"order-success/order-success.template.html"
    });