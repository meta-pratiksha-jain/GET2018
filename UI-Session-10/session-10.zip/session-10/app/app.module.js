'use strict';
 // Define the `UserManagement` module
angular.module('UserManagement', [
    // ...which depends on the `UserManagement` module
    'userList'
]);